This directory contains old documentation files provided by XF's original author prior to revision 4.0.

In general they are no longer applicable and are superceded by information currently provided in the XF root directory.


Dennis LaBelle        xfmaster@nycap.rr.com
